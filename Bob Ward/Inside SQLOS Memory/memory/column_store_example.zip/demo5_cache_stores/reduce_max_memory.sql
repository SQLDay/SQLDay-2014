sp_configure 'max server memory', 400
go
reconfigure
go