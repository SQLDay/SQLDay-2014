sp_configure 'max server memory', 700
go
reconfigure
go