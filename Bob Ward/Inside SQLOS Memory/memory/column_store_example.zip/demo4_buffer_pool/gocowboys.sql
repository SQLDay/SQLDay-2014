use willthecowboysevermakeitbacktothesuperbowl
go
select * from canwewinwithromo
go