sp_configure 'max server memory', 1024
go
reconfigure
go