select * from sys.dm_os_memory_brokers
go