3. Resource Monitor and Brokers

a. Make sure 'max server memory' is 0 and restart SQL Server

b. Load up resource_monitor.sql. You should see RESOURCE_MEMPHYSICAL_HIGH. point out target,
committed, and available physical memory. The <Effect> node is when SQL Server "overrides"
what Windows says because it is monitoring our working set utilization.

c. Load up memory_broker_ring_buffer.sql and talk about how all notifications are to grow.
Run select * from sys.dm_os_memory_brokers. Notice the target is about 80% of overall target

d. Load hercomethebears.sql and run it. This will populate plan cache with a bunch of
procedures.

e. Look at allocations for MEMORYBROKER_FOR_CACHE for pool = 2. Notice the growth

f. Run a multi-user sort job with run_sort.cmd. Look at brokers again. Now shrink,
but notice the targets of all other brokers is lower. This is in response to the RESERVE
broker change

g. Stop the sort and look at SQL Server:Memory Manager/Free Memory (KB) has increased. Why?
This is because sort commits memory from the block alloactor but unlike caches gives
its memory back to SQLOS

h. Load reduce_max_memory.sql. Notice Target Drop in perfmon

i. Now run run_sort.cmd again

j. Check ring buffers for both RM and brokers. Look at brokers DMV. Notice drop in cache
Now stop the sort and notice the rows to indicate internal pressure. Notice the SHRINK and
STABLE rows. Indication of pressure.

k. Load up proc cache again hercomethebears.sql. Notice our increase in allocations
for MEMORYBROKER_FOR_CACHE.

l. Now let's run eatmem.exe and chew up physical memory. Try to run it like this from
the command prompt: eatmem.exe 12000000000

Note this is not a SHRINK situation for the brokers since it has nothing to do with their
own memory allocation. it is all about exteranl pressure and RM notifying all clerks 
including caches to shrink.

m. Look at RM ring buffer, brokers DMV, and Target in Perfmon all adjust down due to
low physical memory conditions. need to explain how to read the Indicators. Can anyone
explain why indicators may go high even though eatmem.exe has not ended? Because its
working set was trimmed a bit to get back some physical memory.
