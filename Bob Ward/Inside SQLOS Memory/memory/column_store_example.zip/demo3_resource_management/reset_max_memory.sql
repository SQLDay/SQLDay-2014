sp_configure 'max server memory', 0
go
reconfigure
go