use willthecowboysevermakeitbacktothesuperbowl
go
select * from canwewinwithromo
order by col2
go