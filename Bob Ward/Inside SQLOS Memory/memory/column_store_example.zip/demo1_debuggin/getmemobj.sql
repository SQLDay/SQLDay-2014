select * from sys.dm_os_memory_objects where type = 'MEMOBJ_SNIPACKETOBJECTSTORE'
go