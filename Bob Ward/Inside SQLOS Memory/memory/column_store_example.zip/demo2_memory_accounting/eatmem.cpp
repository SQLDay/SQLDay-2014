// eatmem.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <Windows.h>

// Reserve ~24Gb
#define MAX_RESERVE 24000000000

int _tmain(int argc, _TCHAR* argv[])
{
	// need this for cout
	using namespace std;

	int iret = 0;
	INT64 iNumBytesToCommit = 0;
	INT64 iCommitSize = 65536; // Default is 64Kb to commit each block
	INT64 iBytesCommitted = 0;
	LPVOID resptr = NULL;
	LPVOID commitptr = NULL;
	BOOL bshouldcontinue = FALSE;

	// 2nd argument is max size to commit
	if (argc > 1)
		iNumBytesToCommit = _tstoi64((_TCHAR *)argv[1]);
	// 3rd argument is commit block size with a default of 64Kb
	if (argc > 2)
		iCommitSize = _tstoi64((_TCHAR *)argv[1]);

	// Reserve a massive amount up front and commit from that
	resptr = VirtualAlloc(NULL, MAX_RESERVE, MEM_RESERVE, PAGE_READWRITE);
	if (resptr)
	{
		do {
			commitptr = VirtualAlloc((BYTE *)resptr+iBytesCommitted, iCommitSize, MEM_COMMIT, PAGE_READWRITE);
			iret = GetLastError();
			if ((commitptr) && (!iret))
			{
				// Touch ptr to get into working set
				SecureZeroMemory(commitptr, iCommitSize);
				iBytesCommitted += iCommitSize;
			}
		}
		// Loop while bytes committes is less than max user specified and less than total reservation
		// and ptr still valid (in case of failure).
		while ((iBytesCommitted < iNumBytesToCommit) && (iBytesCommitted < MAX_RESERVE) && (commitptr) && (!iret));
	}
	
	cout << "Bytes reserved = " << MAX_RESERVE << endl;
	cout << "Bytes commited = " << iBytesCommitted << endl;
	cout << "Last error = " << iret << endl;
	cout << "End?";
	cin >> bshouldcontinue;

	return 0;
}

